(function ($) {
	"use strict";
    
    jQuery(document).ready(function($){
            // This code is use for isotop masonary.
        ///////////////////////////////////////////////////////
    
        
  
        
        
        
    });

    jQuery(window).load(function(){
        $(".century-preloader").fadeOut(500);
    });
   

}(jQuery));